# slout

Mensajería en tiempo real: cuentas, chats privados, **grupos**, **envío de imágenes**, **notificaciones push con la app cerrada**, estado en línea, "escribiendo…", doble check, tema claro/oscuro.

## Pasos (solo una vez)
1. Sube esta carpeta a un repositorio de GitHub.
2. En render.com: New > Blueprint > elige tu repositorio. Se despliega solo con `render.yaml`. Copia la URL https que te dé (ej. https://slout.onrender.com).
3. Convierte la app a APK (elige una):
   - **Recomendada (incluye notificaciones con la app cerrada):** entra en https://www.pwabuilder.com, pega tu URL, pulsa "Package for stores" > Android y descarga el APK.
   - **Alternativa con GitHub:** Actions > "Crear APK de slout" > Run workflow > pega tu URL > descarga `slout-apk`. Este APK funciona igual, pero sin notificaciones push con la app cerrada (eso requeriría Firebase).

## Notas
- Las notificaciones push requieren HTTPS (Render ya lo incluye). Al iniciar sesión el navegador pide permiso; también está en el menú ☰ > "Activar notificaciones".
- Las imágenes se guardan junto a data.json (carpeta uploads). El plan gratuito de Render pierde cuentas, mensajes e imágenes al reiniciar: añade un disco persistente y define DB_FILE (por ejemplo /datos/data.json).
- Prueba local: `npm install && npm start` y abre http://localhost:3000 (las notificaciones push solo funcionan en HTTPS o localhost).
- Se puede instalar sin APK: abre la URL en Chrome > menú ⋮ > "Instalar aplicación".

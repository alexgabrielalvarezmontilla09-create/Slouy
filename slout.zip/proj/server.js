// slout: servidor HTTP estático + WebSocket + Web Push. Dependencias: ws, web-push.
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { WebSocketServer } = require('ws');
const webpush = require('web-push');

const PORT = process.env.PORT || 3000;
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data.json');
const UP = path.join(path.dirname(DB_FILE), 'uploads');
const PUB = path.join(__dirname, 'public');
fs.mkdirSync(UP, { recursive: true });

let db = { users: {}, msgs: [], groups: {} };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))); } catch {}
if (!db.vapid) { db.vapid = webpush.generateVAPIDKeys(); fs.writeFileSync(DB_FILE, JSON.stringify(db)); }
webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@slout.app', db.vapid.publicKey, db.vapid.privateKey);
let dirty = false;
const save = () => { dirty = true; };
setInterval(() => { if (dirty) { dirty = false; fs.writeFile(DB_FILE, JSON.stringify(db), () => {}); } }, 2000);

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' };
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0]);
  if (p === '/') p = '/index.html';
  const up = p.startsWith('/uploads/');
  const base = up ? UP : PUB;
  const f = path.join(base, path.normalize(up ? p.slice(9) : p));
  if (!f.startsWith(base)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, d) => {
    if (e) { res.writeHead(404); return res.end('No encontrado'); }
    const h = { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' };
    if (up) h['Cache-Control'] = 'public, max-age=31536000, immutable';
    res.writeHead(200, h); res.end(d);
  });
});

const wss = new WebSocketServer({ server, maxPayload: 5 * 1024 * 1024 });
const online = new Map(); // usuario -> Set<ws>
const hash = (p, salt) => crypto.scryptSync(p, salt, 32).toString('hex');
const send = (ws, o) => ws.readyState === 1 && ws.send(JSON.stringify(o));
const toUser = (u, o) => (online.get(u) || []).forEach(w => send(w, o));
const broadcast = o => wss.clients.forEach(w => send(w, o));
const members = g => db.groups[g]?.members || [];

function notify(u, m) {
  const rec = db.users[u];
  if (!rec || !rec.subs || !rec.subs.length || online.has(u)) return;
  const title = m.g ? db.groups[m.g].name : '@' + m.from;
  const body = (m.g ? '@' + m.from + ': ' : '') + (m.img && !m.text ? '📷 Foto' : m.text);
  const payload = JSON.stringify({ title, body, tag: m.g ? 'g:' + m.g : m.from });
  rec.subs.forEach(s => webpush.sendNotification(s, payload, { TTL: 3600 }).catch(e => {
    if (e.statusCode === 404 || e.statusCode === 410) { rec.subs = rec.subs.filter(x => x.endpoint !== s.endpoint); save(); }
  }));
}
function pushGroup(id) {
  const g = db.groups[id];
  const msgs = db.msgs.filter(m => m.g === id).slice(-200);
  g.members.forEach(u => toUser(u, { type: 'group', group: g, msgs }));
}

wss.on('connection', ws => {
  let me = null;
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  const toast = text => send(ws, { type: 'toast', text });

  const login = (u, token) => {
    me = u;
    if (!online.has(u)) online.set(u, new Set());
    online.get(u).add(ws);
    const groups = Object.values(db.groups).filter(g => g.members.includes(u));
    const gids = new Set(groups.map(g => g.id));
    const msgs = db.msgs.filter(m => (m.g ? gids.has(m.g) : m.from === u || m.to === u)).slice(-3000);
    const peers = [...new Set(msgs.filter(m => !m.g).map(m => (m.from === u ? m.to : m.from)))]
      .map(p => ({ user: p, online: online.has(p), seen: db.users[p]?.seen || 0 }));
    send(ws, { type: 'authed', user: u, token, msgs, peers, groups, gread: db.users[u].gread || {}, vapid: db.vapid.publicKey });
    broadcast({ type: 'presence', user: u, online: true });
  };

  ws.on('message', raw => {
    let d; try { d = JSON.parse(raw); } catch { return; }
    if (!me) {
      const u = String(d.user || '').trim().toLowerCase();
      if (d.type === 'resume') {
        const rec = db.users[u];
        if (rec && rec.tokens.includes(d.token)) return login(u, d.token);
        return send(ws, { type: 'error', code: 'resume', text: 'Sesión caducada' });
      }
      if (d.type !== 'auth') return;
      if (!/^[a-z0-9_]{3,20}$/.test(u)) return send(ws, { type: 'error', text: 'Usuario: 3 a 20 letras, números o _' });
      const pass = String(d.pass || '');
      let rec = db.users[u];
      if (d.mode === 'register') {
        if (rec) return send(ws, { type: 'error', text: 'Ese usuario ya existe' });
        if (pass.length < 6) return send(ws, { type: 'error', text: 'La contraseña necesita al menos 6 caracteres' });
        const salt = crypto.randomBytes(8).toString('hex');
        rec = db.users[u] = { salt, hash: hash(pass, salt), tokens: [], seen: 0, subs: [], gread: {} };
      } else if (!rec || rec.hash !== hash(pass, rec.salt)) {
        return send(ws, { type: 'error', text: 'Usuario o contraseña incorrectos' });
      }
      const token = crypto.randomBytes(24).toString('hex');
      rec.tokens = [...rec.tokens.slice(-4), token];
      save();
      return login(u, token);
    }
    const rec = db.users[me];

    if (d.type === 'search') {
      const q = String(d.q || '').toLowerCase().trim();
      if (q.length < 2) return send(ws, { type: 'results', users: [] });
      const users = Object.keys(db.users).filter(x => x !== me && x.includes(q)).slice(0, 20)
        .map(x => ({ user: x, online: online.has(x), seen: db.users[x].seen }));
      send(ws, { type: 'results', users });
    } else if (d.type === 'msg') {
      const text = String(d.text || '').trim().slice(0, 4000);
      if (d.g) { if (!members(d.g).includes(me)) return; } else if (d.to === me || !db.users[d.to]) return;
      let img = null;
      if (d.img) {
        const pre = 'data:image/jpeg;base64,';
        if (typeof d.img !== 'string' || !d.img.startsWith(pre) || d.img.length > 4e6) return toast('Imagen no válida o demasiado grande');
        const buf = Buffer.from(d.img.slice(pre.length), 'base64');
        if (buf[0] !== 0xFF || buf[1] !== 0xD8) return toast('Imagen no válida');
        const name = crypto.randomUUID() + '.jpg';
        fs.writeFileSync(path.join(UP, name), buf);
        img = '/uploads/' + name;
      }
      if (!text && !img) return;
      const msg = { id: crypto.randomUUID(), from: me, ts: Date.now(), read: false, text };
      if (d.g) msg.g = d.g; else msg.to = d.to;
      if (img) msg.img = img;
      db.msgs.push(msg); save();
      new Set(d.g ? members(d.g) : [me, d.to]).forEach(u => { toUser(u, { type: 'msg', msg }); if (u !== me) notify(u, msg); });
    } else if (d.type === 'typing') {
      toUser(d.to, { type: 'typing', from: me });
    } else if (d.type === 'read') {
      let n = 0;
      db.msgs.forEach(m => { if (!m.g && m.from === d.with && m.to === me && !m.read) { m.read = true; n++; } });
      if (n) { save(); toUser(d.with, { type: 'read', by: me }); }
    } else if (d.type === 'gread') {
      rec.gread = rec.gread || {};
      rec.gread[d.g] = Math.max(rec.gread[d.g] || 0, +d.ts || 0); save();
    } else if (d.type === 'newgroup') {
      const name = String(d.name || '').trim().slice(0, 40);
      if (!name) return toast('Pon un nombre al grupo');
      const list = [...new Set((d.members || []).map(x => String(x).trim().toLowerCase()))].filter(x => x && x !== me).slice(0, 199);
      const bad = list.filter(x => !db.users[x]);
      if (bad.length) return toast('No existen: ' + bad.map(x => '@' + x).join(', '));
      const id = crypto.randomUUID().slice(0, 8);
      db.groups[id] = { id, name, owner: me, members: [me, ...list], created: Date.now() };
      save(); pushGroup(id);
    } else if (d.type === 'addmember') {
      const g = db.groups[d.g], u = String(d.user || '').replace('@', '').trim().toLowerCase();
      if (!g || g.owner !== me) return;
      if (!db.users[u]) return toast('No existe @' + u);
      if (g.members.includes(u)) return toast('@' + u + ' ya está en el grupo');
      g.members.push(u); save(); pushGroup(g.id);
    } else if (d.type === 'leave') {
      const g = db.groups[d.g];
      if (!g || !g.members.includes(me)) return;
      g.members = g.members.filter(x => x !== me);
      toUser(me, { type: 'left', g: g.id });
      if (!g.members.length) delete db.groups[g.id];
      else { if (g.owner === me) g.owner = g.members[0]; pushGroup(g.id); }
      save();
    } else if (d.type === 'push') {
      const s = d.sub;
      if (!s || typeof s.endpoint !== 'string' || !s.keys) return;
      rec.subs = [...(rec.subs || []).filter(x => x.endpoint !== s.endpoint), s].slice(-5); save();
    } else if (d.type === 'unpush') {
      rec.subs = (rec.subs || []).filter(x => x.endpoint !== d.endpoint); save();
    }
  });

  ws.on('close', () => {
    if (!me) return;
    const set = online.get(me);
    set.delete(ws);
    if (!set.size) {
      online.delete(me);
      db.users[me].seen = Date.now(); save();
      broadcast({ type: 'presence', user: me, online: false, seen: db.users[me].seen });
    }
  });
});

setInterval(() => wss.clients.forEach(w => { if (!w.isAlive) return w.terminate(); w.isAlive = false; w.ping(); }), 30000);
server.listen(PORT, () => console.log('slout listo en http://localhost:' + PORT));
